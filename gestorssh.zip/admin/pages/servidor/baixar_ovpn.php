<?php
require_once("../../../pages/system/seguranca.php");
require_once("../../../pages/system/config.php");
require_once("../../../pages/system/classe.ssh.php");
require_once("../../../pages/system/funcoes.system.php");

protegePagina("admin");

if (isset($_GET["id"])) {
  $id = anti_sql_injection($_GET['id']);

  $SQLSubSSH = "SELECT * FROM ovpn WHERE id = :id";
  $stmt = $conn->prepare($SQLSubSSH);
  $stmt->bindParam(":id", $id);
  $stmt->execute();
  $conta = $stmt->rowCount();

  if ($conta > 0) {
    $arquivo = $stmt->fetch();
    $file = $arquivo['arquivo'];
    $local = "../servidor/ovpn/" . $file;

    if (file_exists($local)) {
      $separa = explode('.', $file);
      $novoNome = $separa[0];
      
      header('Content-Type: application/octet-stream');
      header('Content-Disposition: attachment; filename="' . $novoNome . '"');
      header('Content-Length: ' . filesize($local));

      readfile($local);
      exit;
    } else {
      echo myalertuser('error', 'Arquivo OVPN não foi encontrado na pasta do servidor', '../../home.php?page=servidor/listar');
      exit;
    }
  } else {
    echo myalertuser('error', 'Registro não encontrado', '../../home.php?page=servidor/listar');
    exit;
  }
}
?>
